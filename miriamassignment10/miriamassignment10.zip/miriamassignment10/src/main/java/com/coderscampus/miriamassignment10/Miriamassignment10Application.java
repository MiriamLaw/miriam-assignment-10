package com.coderscampus.miriamassignment10;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Miriamassignment10Application {

	public static void main(String[] args) {
		SpringApplication.run(Miriamassignment10Application.class, args);
	}

}
